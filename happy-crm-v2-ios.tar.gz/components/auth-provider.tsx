'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { User } from '@supabase/supabase-js'

type AuthContextType = {
  user: User | null
  userRole: string | null
  loading: boolean
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  userRole: null,
  loading: true,
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    console.log('🔧 [AUTH-PROVIDER] useEffect started - HARDCODED MODE');
    const supabase = createClient()
    
    // SIMPLIFIED: Get session and immediately set superuser role
    const initAuth = async () => {
      console.log('🔑 [AUTH-PROVIDER] Getting initial session...');
      
      // Önce bypass session'ı kontrol et
      const bypassSession = localStorage.getItem('sb-kvjblasewcrztzcfrkgq-auth-token');
      if (bypassSession) {
        try {
          const parsed = JSON.parse(bypassSession);
          if (parsed.user && parsed.user.email) {
            console.log('🔓 [AUTH-PROVIDER] Bypass session found:', parsed.user.email);
            setUser(parsed.user);
            setUserRole('superuser');
            setLoading(false);
            return; // Bypass session kullanıldı, normal flow'u atla
          }
        } catch (error) {
          console.log('⚠️ [AUTH-PROVIDER] Invalid bypass session, clearing...');
          localStorage.removeItem('sb-kvjblasewcrztzcfrkgq-auth-token');
        }
      }
      
      // Normal Supabase session kontrolü
      const { data: { session }, error } = await supabase.auth.getSession()
      console.log('📋 [AUTH-PROVIDER] Initial session result:', { 
        hasSession: !!session, 
        hasUser: !!session?.user,
        userEmail: session?.user?.email
      });
      
      const currentUser = session?.user ?? null
      setUser(currentUser)
      
      if (currentUser) {
        console.log('👤 [AUTH-PROVIDER] User found, setting hardcoded superuser role');
        setUserRole('superuser') // HARDCODED for testing
      } else {
        console.log('❌ [AUTH-PROVIDER] No user found');
        setUserRole(null)
      }
      
      setLoading(false)
      console.log('✅ [AUTH-PROVIDER] Auth complete - Role: superuser (hardcoded)');
    }

    // MINIMAL auth state listener
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('🔄 [AUTH-PROVIDER] Auth event:', event);
      
      if (event === 'TOKEN_REFRESHED') return // Skip token refresh
      
      // Bypass session kontrolü
      const bypassSession = localStorage.getItem('sb-kvjblasewcrztzcfrkgq-auth-token');
      if (bypassSession) {
        try {
          const parsed = JSON.parse(bypassSession);
          if (parsed.user && parsed.user.email) {
            console.log('🔓 [AUTH-PROVIDER] Using bypass session in listener:', parsed.user.email);
            setUser(parsed.user);
            setUserRole('superuser');
            setLoading(false);
            return;
          }
        } catch (error) {
          localStorage.removeItem('sb-kvjblasewcrztzcfrkgq-auth-token');
        }
      }
      
      // Normal session işleme
      const currentUser = session?.user ?? null
      setUser(currentUser)
      
      if (currentUser) {
        console.log('👤 [AUTH-PROVIDER] Setting hardcoded superuser role');
        setUserRole('superuser') // HARDCODED
      } else {
        setUserRole(null)
      }
      
      setLoading(false)
    })

    initAuth()

    return () => subscription.unsubscribe()
  }, [])

  return (
    <AuthContext.Provider value={{ user, userRole, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
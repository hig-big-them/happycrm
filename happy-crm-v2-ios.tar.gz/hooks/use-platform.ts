import { useState, useEffect } from 'react'

interface PlatformInfo {
  isIOS: boolean
  isAndroid: boolean
  isMobile: boolean
  isCapacitor: boolean
  isNative: boolean
  platform: 'ios' | 'android' | 'web'
}

export function usePlatform(): PlatformInfo {
  const [platform, setPlatform] = useState<PlatformInfo>({
    isIOS: false,
    isAndroid: false,
    isMobile: false,
    isCapacitor: false,
    isNative: false,
    platform: 'web'
  })

  useEffect(() => {
    if (typeof window === 'undefined') return

    const userAgent = window.navigator.userAgent
    const isCapacitor = !!(window as any).Capacitor
    const isIOS = /iPad|iPhone|iPod/.test(userAgent) || 
                  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
    const isAndroid = /Android/.test(userAgent)
    const isMobile = isIOS || isAndroid || /Mobile/.test(userAgent)

    setPlatform({
      isIOS,
      isAndroid,
      isMobile,
      isCapacitor,
      isNative: isCapacitor,
      platform: isIOS ? 'ios' : isAndroid ? 'android' : 'web'
    })
  }, [])

  return platform
}

// iOS specific utilities
export function getIOSVersion(): number | null {
  if (typeof window === 'undefined') return null
  
  const match = window.navigator.userAgent.match(/OS (\d+)_(\d+)_?(\d+)?/)
  if (match) {
    return parseInt(match[1], 10)
  }
  return null
}

export function isIOSStandalone(): boolean {
  if (typeof window === 'undefined') return false
  return (window.navigator as any).standalone === true
}

// Safe area utilities for iOS
export function getSafeAreaInsets() {
  if (typeof window === 'undefined') return { top: 0, bottom: 0, left: 0, right: 0 }
  
  const computedStyle = getComputedStyle(document.documentElement)
  return {
    top: parseInt(computedStyle.getPropertyValue('env(safe-area-inset-top)') || '0', 10),
    bottom: parseInt(computedStyle.getPropertyValue('env(safe-area-inset-bottom)') || '0', 10),
    left: parseInt(computedStyle.getPropertyValue('env(safe-area-inset-left)') || '0', 10),
    right: parseInt(computedStyle.getPropertyValue('env(safe-area-inset-right)') || '0', 10),
  }
} 
const { createClient } = require('@supabase/supabase-js');

// Environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Missing environment variables:');
  console.error('NEXT_PUBLIC_SUPABASE_URL:', !!supabaseUrl);
  console.error('SUPABASE_SERVICE_ROLE_KEY:', !!supabaseServiceKey);
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

const users = [
  {
    email: 'halilg@gmail.com',
    password: 'h01h0203',
    fullName: 'Halil Admin',
    role: 'admin',
    username: 'halilg'
  },
  {
    email: 'halilgurel@gmail.com',
    password: 'h01h0203',
    fullName: 'Halil Superuser',
    role: 'superuser',
    username: 'halilgurel'
  },
  {
    email: 'them4a1@gmail.com',
    password: 'h01h0203',
    fullName: 'Test User',
    role: 'user',
    username: 'them4a1'
  }
];

async function createUser(userData) {
  console.log(`\n🚀 Creating ${userData.role}: ${userData.email}`);
  
  try {
    // 1. Check if user already exists
    console.log('🔍 Checking if user exists...');
    const { data: existingUsers } = await supabase.auth.admin.listUsers();
    const existingUser = existingUsers?.users?.find(u => u.email === userData.email);

    let userId;
    
    if (existingUser) {
      console.log('👤 User already exists, updating metadata...');
      userId = existingUser.id;
      
      // Update existing user's metadata
      const { error: updateError } = await supabase.auth.admin.updateUserById(userId, {
        user_metadata: {
          full_name: userData.fullName
        },
        app_metadata: {
          role: userData.role
        }
      });
      
      if (updateError) {
        console.error('💥 Update user metadata failed:', updateError);
        return;
      }
    } else {
      // Create new user
      console.log('👤 Creating new auth user...');
      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email: userData.email,
        password: userData.password,
        email_confirm: true,
        user_metadata: {
          full_name: userData.fullName
        },
        app_metadata: {
          role: userData.role
        }
      });

      if (authError) {
        console.error('💥 Auth user creation failed:', authError);
        return;
      }
      
      userId = authUser.user.id;
      console.log('✅ Auth user created:', userId);
    }

    // 2. Create or update user profile
    console.log('📝 Creating/updating user profile...');
    const { error: profileError } = await supabase
      .from('user_profiles')
      .upsert({
        id: userId,
        email: userData.email,
        full_name: userData.fullName,
        role: userData.role,
        username: userData.username,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

    if (profileError) {
      console.error('💥 Profile creation/update failed:', profileError);
      return;
    }

    console.log('✅ User profile created/updated');

    // 3. Verify creation
    console.log('🔍 Verifying user creation...');
    const { data: profile, error: verifyError } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (verifyError) {
      console.error('💥 Verification failed:', verifyError);
      return;
    }

    console.log('🎉 User created/updated successfully!');
    console.log('📊 User details:', {
      id: profile.id,
      email: profile.email,
      role: profile.role,
      fullName: profile.full_name,
      username: profile.username
    });

  } catch (error) {
    console.error('💥 Unexpected error:', error);
  }
}

async function createAllUsers() {
  console.log('🔧 Creating system users...\n');
  
  for (const userData of users) {
    await createUser(userData);
  }
  
  console.log('\n✅ All users processed!');
  
  // List all users
  console.log('\n📋 Current system users:');
  const { data: profiles } = await supabase
    .from('user_profiles')
    .select('id, email, role, username')
    .order('role');
    
  console.table(profiles);
}

createAllUsers(); 
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

// Read .env.local manually
let supabaseUrl, supabaseServiceKey;
try {
  const envContent = fs.readFileSync('.env.local', 'utf8');
  const envLines = envContent.split('\n');
  
  for (const line of envLines) {
    const [key, value] = line.split('=');
    if (key === 'NEXT_PUBLIC_SUPABASE_URL') {
      supabaseUrl = value;
    } else if (key === 'SUPABASE_SERVICE_ROLE_KEY') {
      supabaseServiceKey = value;
    }
  }
} catch (error) {
  console.error('❌ .env.local dosyası okunamadı:', error.message);
}

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Missing environment variables:');
  console.error('NEXT_PUBLIC_SUPABASE_URL:', !!supabaseUrl);
  console.error('SUPABASE_SERVICE_ROLE_KEY:', !!supabaseServiceKey);
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

async function createSuperUser() {
  console.log('🚀 Starting superuser creation...');
  
  const email = 'onur@happysmileclinics.com';
  const password = 'o01o0203';
  const fullName = 'Onur Admin';
  const role = 'super_admin';

  try {
    // 1. Check if user exists first
    const { data: { users }, error: listError } = await supabase.auth.admin.listUsers();
    
    if (listError) {
      console.error('❌ Cannot list users:', listError.message);
      return;
    }
    
    let user = users.find(u => u.email === email);
    
    if (!user) {
      console.log('👤 Creating new auth user...');
      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: {
          full_name: fullName
        },
        app_metadata: {
          role: role
        }
      });

      if (authError) {
        console.error('💥 Auth user creation failed:', authError);
        return;
      }

      user = authUser.user;
      console.log('✅ Auth user created:', user.id);
    } else {
      console.log('👤 User already exists, updating to superuser...');
      
      // Update existing user to superuser
      const { data: updatedUser, error: updateError } = await supabase.auth.admin.updateUserById(
        user.id,
        {
          app_metadata: {
            role: role
          }
        }
      );

      if (updateError) {
        console.error('💥 User update failed:', updateError);
        return;
      }

      console.log('✅ User updated to superuser');
    }

    // 2. Update or create user profile
    console.log('📝 Updating user profile...');
    const { error: profileError } = await supabase
      .from('user_profiles')
      .upsert({
        id: user.id,
        email: email,
        full_name: fullName,
        role: role,
        username: email.split('@')[0],
        updated_at: new Date().toISOString()
      });

    if (profileError) {
      console.error('💥 Profile creation failed:', profileError);
      return;
    }

    console.log('✅ User profile updated');

    // 3. Verify the superuser was created correctly
    console.log('🔍 Verifying superuser...');
    
    const { data: { users: verifyUsers }, error: verifyError } = await supabase.auth.admin.listUsers();
    
    if (verifyError) {
      console.error('❌ Verification failed:', verifyError.message);
      return;
    }

    const superuser = verifyUsers.find(u => u.email === email);
    if (superuser && superuser.app_metadata?.role === role) {
      console.log('🎉 SUCCESS! Superuser created successfully!');
      console.log('📧 Email:', email);
      console.log('🔑 Role:', superuser.app_metadata.role);
      console.log('🆔 ID:', superuser.id);
    } else {
      console.error('❌ Verification failed - role not set correctly');
    }

  } catch (error) {
    console.error('💥 Unexpected error:', error.message);
  }
}

// Run the function
createSuperUser();
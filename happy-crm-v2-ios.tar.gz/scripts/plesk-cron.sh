#!/bin/bash

# Plesk Cron Job Script for Happy Transfer Deadline Monitoring
# Bu script Plesk sunucularında her 2-5 dakikada çalıştırılacak

# Configuration
API_URL="https://happy-transfer.vercel.app/api/cron/check-transfer-deadlines"
CRON_TOKEN="eLyhkLlOgWYNZNlycl5ipIPVGJ2OxRic"  # Gerçek token'ı bu şekilde kullanın
LOG_FILE="/var/log/happy-transfer-cron.log"
MAX_TIMEOUT=30

# Function to log with timestamp
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Function to send notification
send_notification() {
    log_message "🔄 Starting deadline check via Plesk cron..."
    
    # Call the API endpoint
    RESPONSE=$(curl -X POST "$API_URL" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $CRON_TOKEN" \
        -H "x-external-cron: plesk" \
        -H "x-cron-server: $(hostname)" \
        --max-time $MAX_TIMEOUT \
        --silent \
        --show-error \
        --write-out "HTTPSTATUS:%{http_code}" 2>&1)
    
    # Extract HTTP status and response body
    HTTP_STATUS=$(echo "$RESPONSE" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2)
    BODY=$(echo "$RESPONSE" | sed 's/HTTPSTATUS:[0-9]*$//')
    
    # Log the result
    if [ "$HTTP_STATUS" = "200" ]; then
        log_message "✅ Deadline check successful - HTTP $HTTP_STATUS"
        log_message "Response: $BODY"
        echo "SUCCESS: Deadline check completed"
    else
        log_message "❌ Deadline check failed - HTTP $HTTP_STATUS"
        log_message "Error: $RESPONSE"
        echo "ERROR: Deadline check failed with status $HTTP_STATUS"
        exit 1
    fi
}

# Main execution
main() {
    # Check if curl is available
    if ! command -v curl &> /dev/null; then
        log_message "❌ ERROR: curl is not installed"
        echo "ERROR: curl is required but not installed"
        exit 1
    fi
    
    # Check if token is configured
    if [ "$CRON_TOKEN" = "YOUR_CRON_API_TOKEN_HERE" ]; then
        log_message "❌ ERROR: CRON_TOKEN not configured"
        echo "ERROR: Please configure CRON_TOKEN in the script"
        exit 1
    fi
    
    # Create log file if it doesn't exist
    touch "$LOG_FILE" 2>/dev/null || LOG_FILE="/tmp/happy-transfer-cron.log"
    
    # Run the notification check
    send_notification
}

# Execute main function
main "$@" 
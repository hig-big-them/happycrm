const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

// Read environment variables manually since dotenv might not be installed
function loadEnvVars() {
  const envPath = path.join(__dirname, '..', '.env.local');
  const envContent = fs.readFileSync(envPath, 'utf8');
  const envVars = {};
  
  envContent.split('\n').forEach(line => {
    const [key, ...values] = line.split('=');
    if (key && values.length > 0) {
      envVars[key.trim()] = values.join('=').trim().replace(/^["'](.*)["']$/, '$1');
    }
  });
  
  return envVars;
}

async function createPermissionUsers() {
  console.log('🔧 Setting up permission system users...');
  
  try {
    const env = loadEnvVars();
    
    const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = env.SUPABASE_SERVICE_ROLE_KEY;
    
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error('Missing required environment variables');
    }
    
    console.log('🔑 Creating admin client...');
    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    
    // Define the users we need
    const users = [
      {
        email: 'halilg@gmail.com',
        password: 'h01h0203',
        role: 'admin',
        name: 'Admin User'
      },
      {
        email: 'halilgurel@gmail.com', 
        password: 'h01h0203',
        role: 'superuser',
        name: 'Superuser'
      },
      {
        email: 'them4a1@gmail.com',
        password: 'h01h0203', 
        role: 'user',
        name: 'Regular User'
      }
    ];
    
    console.log('👥 Creating/updating users...');
    
    for (const userData of users) {
      console.log(`\n🔄 Processing ${userData.email} (${userData.role})...`);
      
      // Check if user already exists
      const { data: existingUsers } = await supabase.auth.admin.listUsers();
      const existingUser = existingUsers.users.find(u => u.email === userData.email);
      
      if (existingUser) {
        console.log(`✅ User ${userData.email} already exists, updating role...`);
        
        // Update existing user
        const { data: updatedUser, error: updateError } = await supabase.auth.admin.updateUserById(
          existingUser.id,
          {
            app_metadata: { 
              role: userData.role 
            },
            user_metadata: {
              name: userData.name
            }
          }
        );
        
        if (updateError) {
          console.error(`❌ Error updating ${userData.email}:`, updateError.message);
        } else {
          console.log(`✅ Updated ${userData.email} with role: ${userData.role}`);
        }
      } else {
        console.log(`🆕 Creating new user ${userData.email}...`);
        
        // Create new user
        const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
          email: userData.email,
          password: userData.password,
          email_confirm: true,
          app_metadata: {
            role: userData.role
          },
          user_metadata: {
            name: userData.name
          }
        });
        
        if (createError) {
          console.error(`❌ Error creating ${userData.email}:`, createError.message);
        } else {
          console.log(`✅ Created ${userData.email} with role: ${userData.role}`);
        }
      }
    }
    
    // Verify the setup
    console.log('\n🔍 Verifying user setup...');
    const { data: allUsers } = await supabase.auth.admin.listUsers();
    
    console.log('\n📋 Final user list:');
    for (const user of allUsers.users) {
      const role = user.app_metadata?.role || 'no role';
      console.log(`- ${user.email}: ${role}`);
    }
    
    console.log('\n✅ Permission system users setup completed!');
    
  } catch (error) {
    console.error('💥 Error setting up users:', error.message);
    process.exit(1);
  }
}

createPermissionUsers();
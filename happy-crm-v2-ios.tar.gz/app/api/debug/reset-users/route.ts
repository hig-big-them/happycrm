import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/utils/supabase/service';

export async function POST(request: NextRequest) {
  try {
    // Security check - only allow in development or with specific secret
    const { searchParams } = new URL(request.url);
    const secret = searchParams.get('secret');
    
    if (secret !== 'reset-all-users-h01h0203') {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const supabase = createServiceClient();

    console.log('🔄 Starting user reset process...');

    // 1. Get all existing users from auth.users
    const { data: authUsers, error: authUsersError } = await supabase.auth.admin.listUsers();
    
    if (authUsersError) {
      console.error('Error fetching auth users:', authUsersError);
    } else {
      console.log(`📊 Found ${authUsers.users.length} auth users to delete`);
    }

    // 2. Delete all users from user_profiles first (to avoid foreign key issues)
    console.log('🗑️ Deleting all user profiles...');
    
    // First try to get all profiles to see what we're deleting
    const { data: existingProfiles } = await supabase
      .from('user_profiles')
      .select('id, email, role');
    
    console.log(`📊 Found ${existingProfiles?.length || 0} profiles to delete`);
    
    // Delete all profiles
    const { error: profilesDeleteError } = await supabase
      .from('user_profiles')
      .delete()
      .gte('created_at', '1900-01-01'); // Delete all by using a condition that matches everything

    if (profilesDeleteError) {
      console.error('Error deleting user profiles:', profilesDeleteError);
      // Try alternative deletion method
      console.log('🔄 Trying alternative deletion method...');
      
      if (existingProfiles) {
        for (const profile of existingProfiles) {
          const { error: individualDeleteError } = await supabase
            .from('user_profiles')
            .delete()
            .eq('id', profile.id);
          
          if (individualDeleteError) {
            console.error(`Failed to delete profile ${profile.email}:`, individualDeleteError);
          } else {
            console.log(`🗑️ Deleted profile: ${profile.email}`);
          }
        }
      }
    } else {
      console.log('✅ Deleted all user profiles');
    }

    // 3. Delete all users from auth.users
    if (authUsers?.users) {
      for (const user of authUsers.users) {
        try {
          const { error: deleteError } = await supabase.auth.admin.deleteUser(user.id);
          if (deleteError) {
            console.error(`Error deleting user ${user.email}:`, deleteError);
          } else {
            console.log(`🗑️ Deleted user: ${user.email}`);
          }
        } catch (err) {
          console.error(`Failed to delete user ${user.email}:`, err);
        }
      }
    }

    // 4. Wait a bit for deletions to process
    await new Promise(resolve => setTimeout(resolve, 2000));

    // 5. Create the super admin user
    const superAdminEmail = 'halil@plante.biz';
    const superAdminPassword = 'h01h0203';

    console.log('👑 Creating super admin user...');

    const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
      email: superAdminEmail,
      password: superAdminPassword,
      email_confirm: true,
      user_metadata: {
        full_name: 'Super Admin',
        role: 'super_admin'
      }
    });

    if (createError) {
      console.error('Error creating super admin:', createError);
      return NextResponse.json(
        { 
          success: false, 
          error: 'Failed to create super admin',
          details: createError.message
        },
        { status: 500 }
      );
    }

    console.log('✅ Super admin user created:', newUser.user?.email);

    // 6. Insert into user_profiles with upsert to handle duplicates
    const { error: profileError } = await supabase
      .from('user_profiles')
      .upsert({
        id: newUser.user!.id,
        email: superAdminEmail,
        full_name: 'Super Admin',
        username: 'superadmin',
        role: 'super_admin',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'id'
      });

    if (profileError) {
      console.error('Error creating super admin profile:', profileError);
      return NextResponse.json(
        { 
          success: false, 
          error: 'Failed to create super admin profile',
          details: profileError.message
        },
        { status: 500 }
      );
    }

    console.log('✅ Super admin profile created');

    // 7. Clear any existing sessions/tokens
    const { error: signOutError } = await supabase.auth.admin.signOut(newUser.user!.id, 'global');
    if (signOutError) {
      console.log('Note: Could not sign out user (expected for new user)');
    }

    console.log('🎉 User reset completed successfully');

    return NextResponse.json({
      success: true,
      message: 'All users deleted and super admin created successfully',
      superAdmin: {
        email: superAdminEmail,
        id: newUser.user!.id,
        role: 'super_admin'
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('User reset error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'User reset failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// Only allow POST requests
export async function GET() {
  return NextResponse.json(
    { error: 'Method not allowed. Use POST with proper secret.' },
    { status: 405 }
  );
}
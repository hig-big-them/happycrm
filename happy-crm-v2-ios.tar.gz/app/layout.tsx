import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Navbar } from '../components/navbar'
import { Toaster } from '../components/ui/toaster'
import { ThemeProvider } from '../providers/theme-provider'
import { AuthProvider } from '../components/auth-provider'
import { QueryProvider } from '../lib/providers/query-provider'
import { NotificationPopup } from '../components/messaging/notification-popup'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Happy CRM',
  description: 'Müşteri yönetim ve takip sistemi',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'Happy CRM'
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
    viewportFit: 'cover'
  },
  icons: {
    icon: '/icon-192.png',
    apple: '/icon-192.png'
  },
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#000000' }
  ]
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <body className={`${inter.className} flex flex-col min-h-screen`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <QueryProvider>
            <AuthProvider>
              <Navbar />
              <main className="flex-grow container mx-auto p-4">
                {children}
              </main>
              {/* İleride bir Footer eklenebilir */}
              <Toaster />
              <NotificationPopup />
            </AuthProvider>
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  )
} 